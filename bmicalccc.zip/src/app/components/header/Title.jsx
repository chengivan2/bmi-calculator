import React from "react";
import "../../componentsstsyles/header/Title.css";

export const Title = () => {
  return <h1 className="bmi-calc-title">BMI CALCULATOR</h1>;
};
